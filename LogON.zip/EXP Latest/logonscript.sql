/*
SQLyog Community v9.63 
MySQL - 5.5.15 : Database - logondb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`logondb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `logondb`;

/*Table structure for table `akhileshscrapbook` */

DROP TABLE IF EXISTS `akhileshscrapbook`;

CREATE TABLE `akhileshscrapbook` (
  `email` varchar(25) DEFAULT NULL,
  `scrap` varchar(250) DEFAULT NULL,
  `datetime` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `akhileshscrapbook` */

insert  into `akhileshscrapbook`(`email`,`scrap`,`datetime`) values ('ratisaxena2411@gmail.com','nice','30/04/2016 18:37:23'),('ratisaxena2411@gmail.com','lol','30/04/2016 18:47:41'),('ratisaxena2411@gmail.com','hm','30/04/2016 18:47:56'),('ratisaxena2411@gmail.com','oh yeah','30/04/2016 18:48:28'),('ratisaxena2411@gmail.com','                     agga\r\n       ','30/04/2016 18:51:03'),('ratisaxena2411@gmail.com','                            haw','30/04/2016 18:51:11'),('ratisaxena2411@gmail.com','hm','30/04/2016 18:51:36'),('ratisaxena2411@gmail.com','                         lol   ','30/04/2016 18:51:40');

/*Table structure for table `deependrascrapbook` */

DROP TABLE IF EXISTS `deependrascrapbook`;

CREATE TABLE `deependrascrapbook` (
  `email` varchar(25) DEFAULT NULL,
  `scrap` varchar(250) DEFAULT NULL,
  `datetime` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `deependrascrapbook` */

/*Table structure for table `friendreq` */

DROP TABLE IF EXISTS `friendreq`;

CREATE TABLE `friendreq` (
  `email` varchar(25) DEFAULT NULL,
  `req1` varchar(25) DEFAULT NULL,
  `req2` varchar(25) DEFAULT NULL,
  `req3` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `friendreq` */

insert  into `friendreq`(`email`,`req1`,`req2`,`req3`) values ('akkisharma623@gmail.com','',NULL,NULL),('ratisaxena2411@gmail.com','',NULL,NULL),('deependra.libra@gmail.com','',NULL,NULL);

/*Table structure for table `friends` */

DROP TABLE IF EXISTS `friends`;

CREATE TABLE `friends` (
  `email` varchar(25) DEFAULT NULL,
  `friend` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `friends` */

insert  into `friends`(`email`,`friend`) values ('akkisharma623@gmail.com','deependra.libra@gmail.com'),('ratisaxena2411@gmail.com','akkisharma623@gmail.com'),('deependra.libra@gmail.com','akkisharma623@gmail.com');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`username`,`password`) values ('akkisharma623@gmail.com','akki'),('deependra.libra@gmail.com','d'),('ratisaxena2411@gmail.com','ki');

/*Table structure for table `ratiscrapbook` */

DROP TABLE IF EXISTS `ratiscrapbook`;

CREATE TABLE `ratiscrapbook` (
  `email` varchar(25) DEFAULT NULL,
  `scrap` varchar(250) DEFAULT NULL,
  `datetime` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ratiscrapbook` */

insert  into `ratiscrapbook`(`email`,`scrap`,`datetime`) values ('akkisharma623@gmail.com','Hello Kitty ! :D',NULL),('akkisharma623@gmail.com','Ki haal ?',NULL),('akkisharma623@gmail.com','                            helooooooooo\r\n',NULL);

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `dateofbirth` date NOT NULL,
  `phone` decimal(10,0) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `country` varchar(20) DEFAULT NULL,
  `security` varchar(100) DEFAULT NULL,
  `securityans` varchar(50) DEFAULT NULL,
  `photo` mediumblob,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`firstname`,`lastname`,`gender`,`dateofbirth`,`phone`,`email`,`password`,`country`,`security`,`securityans`,`photo`) values ('Akhilesh','Sharma','Male','1995-09-23','8954316906','akkisharma623@gmail.com','akki','India','Who is your favorite cartoon?','pokemon',NULL),('Deependra','Rastogi','Male','1981-12-12','9876543210','deependra.libra@gmail.com','d','India','Who is your favorite cartoon?','dbz',NULL),('Rati','Saxena','Female','1993-11-24','9411220273','ratisaxena2411@gmail.com','ki','India','Who is your favorite cartoon?','aashi',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
